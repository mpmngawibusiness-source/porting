# MMD G88 (player MMD untuk Android, dioptimalkan Helio G88 / RAM 6 GB)

## Cara dapat APK (tanpa PC / Android Studio)
1. Buat repo GitHub, upload seluruh isi folder ini.
2. Tab **Actions** -> "Build APK" -> tunggu hijau.
3. Unduh artifact `MMD-G88-apk`, pasang `app-release.apk` (izinkan install dari sumber tak dikenal).

## Atau lewat Android Studio
Jalankan `./fetch-libs.sh` sekali (butuh npm + internet), lalu Build > Build APK.

## Pemakaian
Tekan **Muat file**, pilih SEKALIGUS: model (.pmx/.pmd), semua tekstur model
(bmp/png/jpg/tga/sph/spa), gerakan (.vmd), dan musik (opsional).
Model & tekstur bawaan MMD ada di folder UserFile/Model pada zip Anda.

## Setelan untuk G88
Kualitas "Seimbang" + Tekstur 1024 + 30 FPS adalah default. Jika patah-patah:
Hemat + Tekstur 512, matikan Fisika. Tanpa antialias, tanpa bayangan, tanpa outline.
Batasan: bukan editor; hanya pemutar model/gerakan. Efek MME (.fx) tidak didukung.
