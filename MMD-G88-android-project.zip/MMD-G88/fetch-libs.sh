#!/bin/sh
# Ambil three.js (+ MMDLoader, physics, ammo.wasm) ke assets agar APK jalan OFFLINE.
set -e
V=0.160.0
T=$(mktemp -d); cd "$T"; npm init -y >/dev/null; npm i three@$V >/dev/null
S="$T/node_modules/three"
D="$OLDPWD/app/src/main/assets/lib"
mkdir -p "$D/addons/loaders" "$D/addons/animation" "$D/addons/controls" "$D/addons/libs"
cp "$S/build/three.module.js" "$D/"
cp "$S/examples/jsm/loaders/MMDLoader.js" "$S/examples/jsm/loaders/TGALoader.js" "$D/addons/loaders/"
cp "$S/examples/jsm/animation/"{MMDAnimationHelper,MMDPhysics,CCDIKSolver}.js "$D/addons/animation/"
cp "$S/examples/jsm/controls/OrbitControls.js" "$D/addons/controls/"
cp "$S/examples/jsm/libs/"{mmdparser.module.js,ammo.wasm.js,ammo.wasm.wasm} "$D/addons/libs/"
echo "OK -> $D"
